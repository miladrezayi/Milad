# Milad Surveyor 0.1

نسخه MVP شبیه‌ساز توتال‌استیشن برای Android.

قابلیت‌ها:
- Station coordinates E/N/Z
- Azimuth
- Horizontal angle
- Vertical angle
- Slope distance
- محاسبه مختصات نقطه
- ثبت چند نقطه در حافظه برنامه
- نمایش لیست نقاط

قرارداد محاسبات:
Azimuth از شمال و در جهت ساعتگرد بر حسب درجه است.
Vertical Angle برابر 90 درجه یعنی خط دید افقی است.
این برنامه شبیه‌ساز آموزشی است و به سخت‌افزار Leica متصل نمی‌شود.
