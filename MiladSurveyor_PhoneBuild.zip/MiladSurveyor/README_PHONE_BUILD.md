# Milad Surveyor — Phone-only APK build

This project includes a GitHub Actions workflow. You do not need Android Studio or Gradle installed on your phone.

1. Create a GitHub repository from the GitHub mobile app or github.com.
2. Upload all files/folders from this project, including `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab.
4. Open **Build Milad Surveyor APK** and run the workflow (or push to `main`).
5. When it finishes successfully, open the workflow run and download the artifact named `Milad-Surveyor-debug-apk`.
6. Extract it and install `app-debug.apk` on Android.

The debug APK is signed with Android's debug key and is intended for testing.
