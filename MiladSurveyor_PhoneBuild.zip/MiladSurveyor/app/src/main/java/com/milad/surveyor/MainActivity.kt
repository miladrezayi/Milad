package com.milad.surveyor

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.*

data class Point(val name:String, val e:Double, val n:Double, val z:Double)

class MainActivity : Activity() {
    private lateinit var e0: EditText
    private lateinit var n0: EditText
    private lateinit var z0: EditText
    private lateinit var az: EditText
    private lateinit var hz: EditText
    private lateinit var va: EditText
    private lateinit var sd: EditText
    private lateinit var pointName: EditText
    private lateinit var result: TextView
    private val points = mutableListOf<Point>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        scroll.addView(box)

        val title = TextView(this).apply {
            text = "MILAD SURVEYOR\nTotal Station Simulator"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(20,20,20,20)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(16,24,32))
        }
        box.addView(title)

        addSection(box, "STATION")
        e0 = field(box,"E / X ایستگاه","500000.000")
        n0 = field(box,"N / Y ایستگاه","4000000.000")
        z0 = field(box,"Z ایستگاه","100.000")

        addSection(box, "ORIENTATION")
        az = field(box,"Azimuth / سمت (درجه)","0")

        addSection(box, "OBSERVATION")
        hz = field(box,"Horizontal Angle (°)","45")
        va = field(box,"Vertical Angle (°)","90")
        sd = field(box,"Slope Distance (m)","10")
        pointName = field(box,"Point Name","P1")

        val calc = Button(this).apply {
            text = "MEASURE / محاسبه"
            textSize = 17f
            setOnClickListener { calculate() }
        }
        box.addView(calc)

        result = TextView(this).apply {
            textSize = 16f
            setPadding(12,20,12,20)
            text = "نتیجه اینجا نمایش داده می‌شود."
        }
        box.addView(result)

        val clear = Button(this).apply {
            text = "پاک کردن نقاط"
            setOnClickListener { points.clear(); result.text = "نقاط پاک شدند." }
        }
        box.addView(clear)

        val list = Button(this).apply {
            text = "نمایش نقاط برداشت‌شده"
            setOnClickListener { showPoints() }
        }
        box.addView(list)

        setContentView(scroll)
    }

    private fun addSection(parent: LinearLayout, text: String) {
        val t = TextView(this).apply {
            this.text = text
            textSize = 18f
            setTextColor(Color.rgb(21,101,192))
            setPadding(4,28,4,10)
        }
        parent.addView(t)
    }

    private fun field(parent: LinearLayout, hint: String, value: String): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
                    android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        parent.addView(e)
        return e
    }

    private fun d(e: EditText): Double = e.text.toString().trim().replace(',','.').toDouble()

    private fun calculate() {
        try {
            val E0=d(e0); val N0=d(n0); val Z0=d(z0)
            val azimuth=d(az); val horizontal=d(hz); val vertical=d(va); val slope=d(sd)

            // Convention: azimuth is clockwise from North; horizontal angle is added to azimuth.
            val A = Math.toRadians(azimuth + horizontal)
            val V = Math.toRadians(vertical)

            // V=90° is horizontal sight. Vertical component uses cos(V).
            val horizontalDist = slope * sin(V)
            val dE = horizontalDist * sin(A)
            val dN = horizontalDist * cos(A)
            val dZ = slope * cos(V)

            val p=Point(pointName.text.toString().ifBlank{"P${points.size+1}"},
                E0+dE, N0+dN, Z0+dZ)
            points.add(p)

            result.text = """
                ${p.name}
                E / X = %.4f
                N / Y = %.4f
                Z = %.4f

                HD = %.4f m
                ΔE = %.4f
                ΔN = %.4f
                ΔZ = %.4f
            """.trimIndent().format(p.e,p.n,p.z,horizontalDist,dE,dN,dZ)
        } catch(ex: Exception) {
            result.text = "ورودی‌ها را بررسی کن."
        }
    }

    private fun showPoints() {
        if(points.isEmpty()) { result.text="هنوز نقطه‌ای برداشت نشده."; return }
        result.text = points.joinToString("\n\n") {
            "${it.name}   E=${"%.4f".format(it.e)}   N=${"%.4f".format(it.n)}   Z=${"%.4f".format(it.z)}"
        }
    }
}
